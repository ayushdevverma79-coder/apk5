# SmartAttend AI

Attendance and classroom app (student and teacher logins, class codes, subject-wise attendance, leave, announcements, CSV reports).
Web app in `www/`, wrapped as an Android APK with Capacitor, backend on Firebase (Auth + Firestore).

## 1. Firebase setup (once)
1. Create a project at console.firebase.google.com.
2. Build > Authentication > enable **Email/Password**.
3. Build > Firestore Database > create a database, then open **Rules** and paste `firestore.rules`.
4. Project settings > Your apps > add a **Web app**, copy its config into `www/firebase-config.js`.
5. Teachers: have them sign up as students, then in Firestore open `users/<uid>` and change `role` to `teacher`.

## 2. Get the APK from GitHub
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows`).
2. Open the **Actions** tab > "Build Android APK" > Run workflow (it also runs on every push to `main`).
3. When it finishes, download `SmartAttendAI-debug-apk` from the run page, unzip, and install `app-debug.apk` on the phone (allow installs from unknown sources).

Not included: automatic parent emails (add Firebase's "Trigger Email" extension or a Cloud Function), and face recognition / liveness detection.
Note: the debug APK is for testing; a Play Store release needs a signed release build.
